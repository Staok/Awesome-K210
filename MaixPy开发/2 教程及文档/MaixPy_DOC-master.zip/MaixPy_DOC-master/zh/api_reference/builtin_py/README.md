内置类（builtin_py）
===========

`内置类` 库（builtin_py）是对 MaixPy 底层的类进行封装的用户层接口，方便用户使用 MaixPy 它包括以下：

* [fpioa_manager](fm.md)
* [board_info](board_info.md)
* [pye](pye.md)

```python
from board import board_info
from fpioa_manager import fm
```
