Maixhub 常见问题
========

## 怎么制作数据集

参考 [maixhub](https://www.maixhub.com) 训练页面的帮助文档


