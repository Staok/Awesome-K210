# MaixPy 实现细胞计数

> counting-cells

实现细胞计数步骤:

原图——灰度图——腐蚀膨胀——二值化阈值——滤波操作-计数


```python

```
