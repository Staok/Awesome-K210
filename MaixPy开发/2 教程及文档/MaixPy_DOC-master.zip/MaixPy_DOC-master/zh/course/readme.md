MaixPy 手把手教程说明
=========

看本教程之前， 请**务必先看左侧目录【入门必看指南】**

教程是在认为已经完全掌握了前面的 入门 部分的内容的基础上写的


本教程主要分模块地介绍 MaixPy 包含的功能的使用方法，
在看教程时，可能需要配合 API 文档 和 例程仓库[MaixPy_scripts](https://github.com/sipeed/maixpy_scripts) 一同学习
