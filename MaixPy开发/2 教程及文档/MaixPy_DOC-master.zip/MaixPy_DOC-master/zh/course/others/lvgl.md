lvgl [LittlevGL](https://littlevgl.com/)
===========

**现在已经不推荐使用该模块，请使用者具备足够的开发水平，不接收有关于 LVGL 与 AI 功能共用的问题，谢谢配合（2020年12月11日大佬鼠宣）**

请使用带有 LVGL 字样的 bin 固件进行操作。

参考官方文档： [lvgl blog page](https://blog.littlevgl.com/2019-02-20/micropython-bindings)

## 例程

参考 [github 的 MaixPy_Scripts](https://github.com/sipeed/MaixPy_scripts/tree/master/multimedia/gui/lvgl)



