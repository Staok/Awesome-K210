
MaixPy 视频入门教程
========


视频简单介绍了基本的上手过程，事实上文档上会更加详细， 视频只是提供一个比较直观的入门参考，对部分人群来说看视频入门会更加容易， 另外，本视频内的文档版本是最初的版本，新文档目录结构有了适当的调整，请大家举一反三：

<iframe width="800" height="600" src="//player.bilibili.com/player.html?aid=52613549&cid=92076022&page=1" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true"> </iframe>

建议进入[Bilibili](https://www.bilibili.com/video/av52613549?zw)登录看高清版本哦， 如果觉得节奏太慢可以右键调速～
