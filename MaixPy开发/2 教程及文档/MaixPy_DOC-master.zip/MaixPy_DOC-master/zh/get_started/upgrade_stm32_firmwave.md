# MaixGo 更新板载 STM32 调试器固件

MaixGo 开发板板载了一块基于 STM32 的调试器


