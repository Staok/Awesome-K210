Packaged file system
===

Package several files on the PC into a SPIFFS file system image, use kflash to burn to a specific address of the flash, and these files can be read directly on the development board (MaixPy)

See the instructions for details:[pack SPIFFS for MaixPy](https://github.com/sipeed/MaixPy/tree/master/tools/spiffs)

![pack fs](https://cdn.sipeed.com/pack_spiffs_ops.gif)



