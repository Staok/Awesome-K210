Source code compilation
========

Pre-compiled firmware may not meet specific usage scenarios. If you need to modify the configuration, configure and compile the required firmware


Compiled please refer to [build.md](https://github.com/sipeed/MaixPy/blob/master/build.md)



