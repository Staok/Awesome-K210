
Maix库
=======

* [FPIOA](fpioa.md)
* [GPIO](gpio.md)
* [KPU](kpu.md)
* [FFT](fft.md)
* [I2S](i2s.md)
* [Audio](audio.md) 
* [freq](freq.md)
* [utils](utils.md)
