machine
===========

machine 库主要包含了与硬件相关的各种接口，如下：

* [I2C](i2c.md)
* [SPI](spi.md)
* [Timer](timer.md)
* [PWM](pwm.md)
* [UART](uart.md)


