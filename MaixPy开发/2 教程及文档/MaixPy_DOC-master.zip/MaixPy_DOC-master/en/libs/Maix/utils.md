Maix.utils
=====


## gc_heap_size ([size])

Get or set the GC heap size. If you report insufficient memory, you can consider setting a larger size.

### Parameters

None or Pass in a new GC heap size.
* If there is no parameter, just get the heap size;
* If there are parameters, set the heap size, and then restart automatically

### Return value

GC heap size


