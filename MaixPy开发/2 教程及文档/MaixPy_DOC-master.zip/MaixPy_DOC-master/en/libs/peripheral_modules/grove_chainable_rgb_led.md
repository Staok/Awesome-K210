Grove 链式 RGB LED
====


使用两跟线串行连接多个 RGB LED 灯（灯条）

![](../../../assets/grove_rgb_led.jpg)


使用 micropython 语法编写， 例程和资料见 [MaixPy_Scripts](https://github.com/sipeed/MaixPy_scripts/tree/master/modules/grove/chainable_RGB_LED)



