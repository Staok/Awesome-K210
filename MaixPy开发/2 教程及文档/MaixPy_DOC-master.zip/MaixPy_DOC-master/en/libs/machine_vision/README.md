Machine vision
====

It mainly contains classes related to images and displays, including:

* [LCD](lcd.md)
* [Sensor](sensor.md)
* [Image](image.md)



