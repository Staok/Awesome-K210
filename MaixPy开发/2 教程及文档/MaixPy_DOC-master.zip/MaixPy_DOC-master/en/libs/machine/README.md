machine
===========


* [I2C](i2c.md)
* [SPI](spi.md)
* [Timer](timer.md)
* [PWM](pwm.md)
* [UART](uart.md)


## Function unique_id()

Get unique ID


### Return value

32 bytes unique ID


## Function reset()

reset (reboot)


