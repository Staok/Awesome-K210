Contribute to the project
=======

Since this is an open source project, everyone is welcome to join in and improve MaixPy.

Due to the large number of people, we need a code convention (including format, style, etc.)

The following documents describe the coding convention for both the documentation and code:

* [Documentation convention](doc_convention.md)

* [Code convention](code_convention.md)
