MaixPy Video Getting Started Tutorial
========

The video briefly introduces the basic hands-on process. The documentation is a lot more detailed and will help you get used to the board.

<iframe width="800" height="600" src="//player.bilibili.com/player.html?aid=52613549&cid=92076022&page=1" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true"> </iframe>

<br / >
<br / >

<br / ><br / ><br / ><br / >