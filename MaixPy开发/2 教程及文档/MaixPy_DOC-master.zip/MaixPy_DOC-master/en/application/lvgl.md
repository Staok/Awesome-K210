lvgl [LittlevGL](https://littlevgl.com/)
===========

Refer to the official documentation: [lvgl blog page](https://blog.littlevgl.com/2019-02-20/micropython-bindings)

## Demo

Refer to [MaixPy_Scripts on github](https://github.com/sipeed/MaixPy_scripts/tree/master/application/lvgl)

