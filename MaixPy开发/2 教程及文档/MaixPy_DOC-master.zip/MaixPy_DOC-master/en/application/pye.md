pye [Micropython Editor](https://github.com/robert-hh/Micropython-Editor)
======

A file editor written by py, integrated into the MaixPy firmware. With it, you can directly edit files via the serial port terminal.

Usage:

```python

from pye_mp import pye

pye("/sd/boot.py")

```
