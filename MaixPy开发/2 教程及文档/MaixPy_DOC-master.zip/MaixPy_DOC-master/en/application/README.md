Integrated Application
=========


* [pye](./pye.md): Integrated MaixPy file editor. Directly edit files on the board using the serial port.
* [nes](./nes.md): NES game emulator
* [lvgl](./lvgl.md): LittlvGL GUI lib



