Grove Ultrasonic Ranger
=======

<img src="assets/ultrasonic.jpg" width=450 /> <img src="assets/ultrasonic2.jpg" width=450 />


More info see [Seeed Studio Wiki](http://wiki.seeedstudio.com/Grove-Ultrasonic_Ranger/)

## Examples

* [measure](./measure.py)



