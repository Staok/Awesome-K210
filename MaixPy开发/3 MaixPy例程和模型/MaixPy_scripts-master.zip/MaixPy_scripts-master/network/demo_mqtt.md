
Refer to https://github.com/micropython/micropython-lib/tree/master/umqtt.simple

