# edit file by function pye("file_name_in_maixpy_fs")

from pye_mp import pye

pye("/sd/boot.py")

