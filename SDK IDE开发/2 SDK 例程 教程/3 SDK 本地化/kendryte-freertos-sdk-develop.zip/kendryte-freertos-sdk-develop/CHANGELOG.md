Changelog for Kendryte K210
======

## 0.1.0

Kendryte K210 first SDK with FreeRTOS, have fun. 

