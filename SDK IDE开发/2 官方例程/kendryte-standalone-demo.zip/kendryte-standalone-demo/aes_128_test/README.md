AES-128 hardware cipher
=====
include AES-CBC-128/AES-ECB-128/AES-GCM-128.

1.Traversal test.
2.Compare the time spent on hardware aes and software aes.
