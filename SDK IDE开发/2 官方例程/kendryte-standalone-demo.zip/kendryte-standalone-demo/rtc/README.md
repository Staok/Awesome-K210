RTC
=====
1.Set time.
2.Get time.