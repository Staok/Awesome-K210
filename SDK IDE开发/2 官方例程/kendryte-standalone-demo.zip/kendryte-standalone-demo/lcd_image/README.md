SPI LCD
=====
Display dog and bicycle.