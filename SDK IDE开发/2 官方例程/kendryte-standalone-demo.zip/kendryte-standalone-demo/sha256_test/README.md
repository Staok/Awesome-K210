sha256 hardware calculation
=====
Sha256 several strings.

You can check the results at : https://2coin.org/sha256.html
