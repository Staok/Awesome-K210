GPIOHS
=====
LED7 is blinking when pressing key1.