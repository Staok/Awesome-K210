IIC slave test
=====

1.GPIO work as IIC master device.Write data to IIC slave device .Get data from IIC salve device.