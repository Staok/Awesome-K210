TIMER PWM
=====
Let LDE6 being breathing lamp.