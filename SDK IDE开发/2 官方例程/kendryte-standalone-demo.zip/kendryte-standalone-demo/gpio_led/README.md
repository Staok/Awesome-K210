GPIO
=====
Let LED6 blinking.