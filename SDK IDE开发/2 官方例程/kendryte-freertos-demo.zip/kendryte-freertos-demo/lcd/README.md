LCD test
=====

1.Test lcd clear.<br/>
2.Test lcd draw picture.<br/>
3.Test lcd draw string.<br/>
