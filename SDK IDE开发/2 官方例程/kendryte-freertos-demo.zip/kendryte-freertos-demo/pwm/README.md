PWM driver test
=====
"project_cfg.h" is the hardware related configuration files. Include pin config ...

1.Get PWM from pin22.<br/>
2.200KHZ frequency.Every 10 milliseconds will change the duty cycle.