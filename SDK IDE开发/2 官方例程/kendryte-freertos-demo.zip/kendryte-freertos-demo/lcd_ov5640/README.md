DVP test
=====

1.DVP get picture; LCD display.
