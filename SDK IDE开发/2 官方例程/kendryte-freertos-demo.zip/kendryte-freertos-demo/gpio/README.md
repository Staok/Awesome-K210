GPIO driver test
=====
"project_cfg.h" is the hardware related configuration files. Include pin config ...

1.Two tasks have been created.One task is to set gpio output, another task to read gpio input. Please connect pin6 with pin7.