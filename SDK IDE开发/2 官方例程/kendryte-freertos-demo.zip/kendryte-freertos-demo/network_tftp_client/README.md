TFTP client test
=====
1.test tftp get.  

2.test tftp put.  

3.filesystem operation.  