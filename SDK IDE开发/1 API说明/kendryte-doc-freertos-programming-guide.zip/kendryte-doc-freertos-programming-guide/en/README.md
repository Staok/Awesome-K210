# About This Guide

This document provides the programming guide of Kendryte K210 FreeRTOS SDK.

## Corresponding SDK version

Kendryte FreeRTOS SDK v0.4.0 (*9c7b0e0d23e46e87a2bfd4dd86d1a1f0d3c899e9*)

## Revision History

|    Date    |  Ver.  | Revision History |
| ---------- | ------ | ---------------- |
| 2018-10-12 | V0.1.0 | Initial release  |

## Disclaimer

Information in this document, including URL references, is subject to change without notice. THIS DOCUMENT IS PROVIDED AS IS WITH NO WARRANTIES WHATSOEVER, INCLUDING ANY WARRANTY OF MERCHANTABILITY, NON-INFRINGEMENT, FITNESS FOR ANY PARTICULAR PURPOSE, OR ANY WARRANTY OTHERWISE ARISING OUT OF ANY PROPOSAL, SPECIFICATION OR SAMPLE.

All liability, including liability for infringement of any proprietary rights, relating to use of information in this document is disclaimed. No licenses express or implied, by estoppel or otherwise, to any intellectual property rights are granted herein.

All trade names, trademarks and registered trademarks mentioned in this document are property of their respective owners, and are hereby acknowledged.

## Copyright Notice

Copyright © 2018 Canaan Inc. All rights reserved.
