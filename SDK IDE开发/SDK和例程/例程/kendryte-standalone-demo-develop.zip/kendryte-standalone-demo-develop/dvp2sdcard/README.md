DVP2SDCARD
=====
## Press key to store the 320\*240 rgb565 image from dvp into Micro SD Card.

For sipeed m1, press *boot* key.

For KD233, press GPIO key (near the blue rotary switch).