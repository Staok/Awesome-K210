I2C sd3068
=====
1.Set time by i2c.
2.Get time by i2c.