KPU example
=====
20 classes recognition.

SDK v0.5.3 or later.
