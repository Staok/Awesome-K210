UART
=====
* Led6 on when receive 55AA55555555
* Led6 off when receive 55AAAAAAAAAA

SDK v0.5.2 or later
