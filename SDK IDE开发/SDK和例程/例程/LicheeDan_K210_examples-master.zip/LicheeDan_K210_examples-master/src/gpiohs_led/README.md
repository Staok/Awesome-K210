GPIOHS
=====
LED_G is blinking when pressing BOOT.