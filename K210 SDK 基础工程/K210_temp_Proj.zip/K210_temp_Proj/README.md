# hello world project

Thanks for using Kendryte IDE.

This is an empty example project.

If you found a bug, please visit https://github.com/kendryte/kendryte-ide/issues
