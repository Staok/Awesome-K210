#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

#include "fpioa.h"
#include "gpio.h"
#include "gpiohs.h"
//#include "uart.h"
#include "uarths.h"
#include "sysctl.h"
#include "timer.h"
#include "wdt.h"
// #include "bsp.h"

/*库使用注意事项：
  UARTHS，发送使用printf和scanf("%s",&buf);(scanf是死等)，接收在下面用中断+标志位实现，100ms时间间隔认为一次接收
  SPI：例程中，master源文件里面，按照md说明文件里面的电路图，增加了一路从机Ready给主机INT的信号，发送命令cmd函数中，发送完后主机要收到从机拉低Ready信号，才算发送成功一次，可以自己改改
  RTC：搞清楚RTC时钟和备份电源从哪来
  UART和UARTHS不是一个东西，搞清楚各个引脚
  有外部 FLASH 或者 SD卡的时候，就优先把神经网络模型储存在 FLASH 或者SD卡，就不烧写到MCU内部FLASH了，减少MCU内部FLASH烧写次数
*/

/*TODO:
  然后，先研究TF模型转Kmodel，然后K210里面怎么运行模型，搞清楚了这个再继续下面！

  LCD加上
  SD卡文件系统加上
  摄像头驱动加上
*/

#define signal_led_pin 17 /*哪个引脚设为led指示灯，默认IO17*/

uint8_t uarths_receive_echo = 1;   /*uarths是否接收回显*/

#define is_open_wdt 1 /*是否启用看门狗*/

#define uarths_stdio_or_api 0 /*对于uarths，1选择printf和scanf，0选择SDK的API*/
                              /*注意，在uarths的IO口未被fpioa映射的话就调SDK的API，会在那里死机！*/

/*以下是系统变量，一般不用动*/
gpio_pin_value_t signal_led_val = GPIO_PV_HIGH;

volatile uint8_t irq_flag_timer_10ms = 0;
/* 定时器0 通道0 定时10ms中断*/
int irq_time0_ch0_10ms(void *ctx) { irq_flag_timer_10ms = 1; return 0;}

volatile uint8_t irq_flag_timer_100ms = 0;
/* 定时器0 通道1 定时100ms中断*/
int irq_time0_ch1_100ms(void *ctx) { irq_flag_timer_100ms = 1; return 0;}

volatile uint8_t irq_flag_timer_1s = 0;
/* 定时器0 通道2 定时1s中断*/
int irq_time0_ch2_1s(void *ctx) { irq_flag_timer_1s = 1; return 0;}

#if (uarths_stdio_or_api == 0)

#define uarths_receive_MaxNum  200 /*uarths接收缓冲区最大字节数*/
#define uarths_recv_wait_usec  100000UL /*从接收到第一个字节开始，若100ms之内没有再接收到则认为接收完成一次，这里单位是us*/
uint8_t uarths_receive_char[uarths_receive_MaxNum];  /*uarths接收缓冲区*/
volatile uint16_t uarths_receive_num = 0;  /*uarths接收区当前接收到的字节数*/
volatile uint8_t uarths_receive_flag = 0; /*uarths接收标志位，采用时间分段，从接收到第一个字节开始，若100ms之内没有再接收到则认为接收完成一次，标志此标志位*/

volatile uint64_t uarths_last_recv_us = 0;
volatile uint8_t uarths_recv_flag_first = 0;
uint8_t uarths_receive_char_temp;
/*uarths中断*/
int uarths_irq(void *ctx)
{
  /*uarths接收中断*/
  if(UARTHS_RECEIVE == uarths_get_interrupt_mode())
  {
    if (uarths_receive_data(&uarths_receive_char_temp, 1))
    {
      uarths_receive_char[uarths_receive_num++] = uarths_receive_char_temp;

      if(uarths_receive_num >= (uarths_receive_MaxNum - 1))
        uarths_receive_num = (uarths_receive_MaxNum - 1);

      uarths_last_recv_us = sysctl_get_time_us();
      uarths_recv_flag_first = 1;
    }
  }
  /*uarths发送中断*/
  // else if(UARTHS_SEND == uarths_get_interrupt_mode())
  // {

  // }
  return 0;
}
/*uarths处理，必须放到主循环里循环执行*/
void uarths_handle()
{
  /*检测若距离最后一次串口接收，大于uarths_recv_wait_usec us时，标记uarths接收完成标志位*/
  if(uarths_recv_flag_first)
  {
    // if(sysctl_get_time_us() - uarths_last_recv_us >= uarths_recv_wait_usec)
    if( (sysctl_get_time_us() - uarths_last_recv_us) >= 1000000UL)
    {
      uarths_receive_flag = 1;
      uarths_recv_flag_first = 0;

      /*串口接收回显*/
      if(uarths_receive_echo)
      {
        uarths_send_data(uarths_receive_char, uarths_receive_num);
      }
    }
  }
}
#endif

int main(void) {
  /*__________开始初始化序列_______________________________________________________________*/

  /*PLIC初始化外部中断 Init Platform-Level Interrupt Controller(PLIC)*/
  plic_init();

  /*__________IO初始化__________________*/
  gpio_init();

  /*指示灯IO*/
  fpioa_set_function(signal_led_pin, FUNC_GPIO0);
  gpio_set_drive_mode(0, GPIO_DM_OUTPUT);
  gpio_set_pin(0, GPIO_PV_HIGH);

  /*失能板子上自带的esp32，低电平关，EN IO*/
  fpioa_set_function(8, FUNC_GPIO1);
  gpio_set_drive_mode(1, GPIO_DM_OUTPUT);
  gpio_set_pin(1, GPIO_PV_LOW);

  #if (uarths_stdio_or_api == 0)
    /*uarths串口IO*/
    fpioa_set_function(4, FUNC_UARTHS_RX);
    fpioa_set_function(5, FUNC_UARTHS_TX);
  #endif

  /*__________器件初始化__________________*/




  /*__________外设初始化__________________*/
  /*初始化UARTHS，系统默认波特率为115200 8bit 1位停止位 无检验位。*/
  uarths_init();
  #if (uarths_stdio_or_api == 0)
    /*设置UARTHS接收中断 中断FIFO深度为0，即接收到数据立即中断并读取接收到的数据。*/
    uarths_set_interrupt_cnt(UARTHS_RECEIVE , 0);
    /*设置UARTHS中断类型，回调函数以及优先级*/
    uarths_set_irq(UARTHS_RECEIVE ,uarths_irq, NULL, 4);
    uarths_send_data("Hello World\r\n", 13);
  #else
    printf("Hello World\r\n");
  #endif

  /*启用定时器0中断，提供时基*/
  timer_init(TIMER_DEVICE_0);

  /*定时器0，通道0，10ms中断（第三个参数纳秒）*/
  timer_set_interval(TIMER_DEVICE_0, TIMER_CHANNEL_0, 10 * 1000 * 1000);
  /*定时器0，通道0，非单次中断，优先级为1，中断函数为irq_time0_ch0_10ms，传入参数NULL*/
  timer_irq_register(TIMER_DEVICE_0, TIMER_CHANNEL_0, 0, 1, irq_time0_ch0_10ms, NULL);

  /*定时器0，通道1，100ms中断（第三个参数纳秒）*/
  timer_set_interval(TIMER_DEVICE_0, TIMER_CHANNEL_1, 100 * 1000 * 1000);
  /*定时器0，通道1，非单次中断，优先级为2，中断函数为irq_time0_ch1_100ms，传入参数NULL*/
  timer_irq_register(TIMER_DEVICE_0, TIMER_CHANNEL_1, 0, 2, irq_time0_ch1_100ms, NULL);

  /*定时器0，通道2，100ms中断（第三个参数纳秒）*/
  timer_set_interval(TIMER_DEVICE_0, TIMER_CHANNEL_2, 1e9);
  /*定时器0，通道2，非单次中断，优先级为3，中断函数为irq_time0_ch2_1s，传入参数NULL*/
  timer_irq_register(TIMER_DEVICE_0, TIMER_CHANNEL_2, 0, 3, irq_time0_ch2_1s, NULL);

  /*定时器0，通道0 1 2，使能*/
  timer_set_enable(TIMER_DEVICE_0, TIMER_CHANNEL_0, 1);
  timer_set_enable(TIMER_DEVICE_0, TIMER_CHANNEL_1, 1);
  timer_set_enable(TIMER_DEVICE_0, TIMER_CHANNEL_2, 1);

  #if is_open_wdt
    /*启用300ms周期喂狗看门狗0，无中断回调函数和其参数*/
    wdt_init(WDT_DEVICE_0, 300, NULL, NULL);
  #endif

  /*使能系统中断，如果使用中断一定要开启系统中断 Enable global interrupt for machine mode of RISC-V*/
  sysctl_enable_irq();

  /*__________结束初始化序列_______________________________________________________________*/
  #if (uarths_stdio_or_api == 0)
    uint8_t* temp_buf = (uint8_t*)malloc(200);

    sprintf(temp_buf,"Init OK!\r\n" "Compiled in " __DATE__ " " __TIME__ "\r\n");
    uarths_send_data(temp_buf,strlen(temp_buf));

    sprintf(temp_buf,"us now %ld\r\nPLL0 clock %d\r\nCPU clock %d\r\nRTC clock %d\r\n",
          sysctl_get_time_us(),
          sysctl_clock_get_freq(SYSCTL_CLOCK_PLL0),
          sysctl_clock_get_freq(SYSCTL_CLOCK_CPU),
          sysctl_clock_get_freq(SYSCTL_CLOCK_RTC));
    uarths_send_data(temp_buf,strlen(temp_buf));

    free(temp_buf);
  #else
    printf(
        "Init OK!\r\n"
        "Compiled in " __DATE__ " " __TIME__ "\r\n");
    printf("us now %ld\r\nPLL0 clock %d\r\nCPU clock %d\r\nRTC clock %d\r\n",
          sysctl_get_time_us(),
          sysctl_clock_get_freq(SYSCTL_CLOCK_PLL0),
          sysctl_clock_get_freq(SYSCTL_CLOCK_CPU),
          sysctl_clock_get_freq(SYSCTL_CLOCK_RTC));
  #endif

  while (1)
  {
    #if (uarths_stdio_or_api == 0)
    /*串口接收完一次*/
    if(uarths_receive_flag)
    {
      uarths_receive_flag = 0;

      /*处理完数据后，清零接收index*/
      uarths_receive_num = 0;
    }
    #endif

    /*处理10ms周期任务*/
    if (irq_flag_timer_10ms)
    {
      irq_flag_timer_10ms = 0;
    }

    /*处理100ms周期任务*/
    if (irq_flag_timer_100ms)
    {
      irq_flag_timer_100ms = 0;

      #if is_open_wdt
        /*先喂狗*/
        wdt_feed(WDT_DEVICE_0);
      #endif
    }

    /*处理1s周期任务*/
    if (irq_flag_timer_1s)
    {
      irq_flag_timer_1s = 0;

      /*闪烁工作指示灯*/
      gpio_set_pin(0, signal_led_val = !signal_led_val);
    }

#if (uarths_stdio_or_api == 0)
      uarths_handle();  /*uarths处理，必须循环执行*/
    #endif

  }
  return 0;
}
